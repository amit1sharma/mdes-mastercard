package com.adcb.mdes_cs;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.test.context.TestPropertySource;

import com.adcb.mdes_cs.vo.MdesTokenProps;

@EnableAutoConfiguration
@EnableConfigurationProperties(value = { MdesTokenProps.class })
public class TestConfig {}
