package com.adcb.mdes_cs;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.util.JAXBSource;
import javax.xml.transform.Source;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.ws.test.server.MockWebServiceClient;
import org.springframework.ws.test.server.RequestCreators;
import org.springframework.ws.test.server.ResponseMatchers;

import com.adcb.mdes_cs.client.token.modify.activate.req.TokenActivateRequest;
import com.adcb.mdes_cs.client.token.modify.activate.res.TokenActivateResponse;
import com.adcb.mdes_cs.client.token.modify.common.AuditInfo;
import com.adcb.mdes_cs.client.token.modify.common.TokenCommonRequest;
import com.adcb.mdes_cs.client.token.modify.common.TokenError;
import com.adcb.mdes_cs.client.token.modify.delete.req.TokenDeleteRequest;
import com.adcb.mdes_cs.client.token.modify.delete.res.TokenDeleteResponse;
import com.adcb.mdes_cs.client.token.modify.suspend.req.TokenSuspendRequest;
import com.adcb.mdes_cs.client.token.modify.suspend.res.TokenSuspendResponse;
import com.adcb.mdes_cs.client.token.modify.unsuspend.req.TokenUnsuspendRequest;
import com.adcb.mdes_cs.client.token.modify.unsuspend.res.TokenUnsuspendResponse;
import com.adcb.mdes_cs.client.token.modify.update.req.TokenUpdateRequest;
import com.adcb.mdes_cs.client.token.modify.update.res.TokenUpdateResponse;
import com.adcb.mdes_cs.client.token.search.req.SearchRequest;
import com.adcb.mdes_cs.client.token.search.res.SearchResponse;
import com.adcb.mdes_cs.constants.TokenErrorEnum;
import com.adcb.mdes_cs.crypto.AESGCMCrypto;
import com.adcb.mdes_cs.endpoint.TokenServiceEndpoint;
import com.adcb.mdes_cs.helper.TokenHelper;
import com.adcb.mdes_cs.repository.TokenServiceLogRepository;
import com.adcb.mdes_cs.service.TokenService;
import com.adcb.mdes_cs.util.TokenUtils;
import com.adcb.mdes_cs.vo.MdesTokenProps;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.mastercard.api.core.ApiConfig;
import com.mastercard.api.core.security.oauth.OAuthAuthentication;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {TokenService.class, TokenServiceEndpoint.class, TestConfig.class, AESGCMCrypto.class,
})
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class,HibernateJpaAutoConfiguration.class})
@TestPropertySource(locations = "classpath:application_test.properties")
public class MdesMasterCardApplicationTests {

	@MockBean
	private TokenServiceLogRepository repository;

	@Autowired
	private  MdesTokenProps tokenServiceProps;

	@Autowired
	private  AESGCMCrypto encryption;

	@Autowired
	private ApplicationContext applicationContext;

	private MockWebServiceClient mockClient;

	@Before
	public void init(){
		mockClient = MockWebServiceClient.createClient(applicationContext);
	}

	@Test
	public void invalid_search_response_test() throws Exception {
		SearchRequest request = new SearchRequest();
		request.setTokenUniqueReference("DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c");

		SearchResponse response = new SearchResponse();
		TokenError error = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
		response.setTokenError(error);


		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)))
		.andExpect(ResponseMatchers.payload(getSourceFromJAXB(response)));

		assertNull(response.getAccounts());
		assertNotNull(response.getTokenError());


	}


	@Test
	public void valid_search_response_test() throws Exception {
		SearchRequest request = new SearchRequest(); request.setTokenUniqueReference(
				"DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c");
		request.setAuditInfo(setAuditInfo());


		Map<String, String> namespaces = new HashMap<>();
		namespaces.put("ns2","http://adcb.com/MDES-CS/client/token/search/res");
		namespaces.put("ns3","http://adcb.com/MDES-CS/client/token/common");

		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)
				)) .andExpect(ResponseMatchers
						.xpath("/ns2:SearchResponse/ns2:Accounts/ns2:Account/ns2:Tokens/ns2:Token/ns2:TokenUniqueReference/text()",namespaces)
						.evaluatesTo("DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c"));

	}

	@Test
	public void invalid_activate_response_test() throws Exception {
		TokenActivateRequest request = new TokenActivateRequest();

		TokenActivateResponse response = new TokenActivateResponse();
		TokenError error = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
		response.setTokenError(error);


		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)))
		.andExpect(ResponseMatchers.payload(getSourceFromJAXB(response)));

		assertNull(response.getToken());
		assertNotNull(response.getTokenError());

	}




	@Test
	public void valid_activate_response_test() throws Exception {
		TokenActivateRequest request = new TokenActivateRequest();
		request.setTokenCommonRequest(setTokenCommonRequest("A"));

		Map<String, String> namespaces = new HashMap<>();
		namespaces.put("ns3","http://adcb.com/MDES-CS/client/token/activate/res");
		namespaces.put("ns2","http://adcb.com/MDES-CS/client/token/common");

		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)
				)) .andExpect(ResponseMatchers
						.xpath("/ns3:TokenActivateResponse/ns3:Token/ns2:TokenUniqueReference/text()",namespaces)
						.evaluatesTo("DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c")); 

	}

	@Test
	public void invalid_update_response_test() throws Exception {
		TokenUpdateRequest request = new TokenUpdateRequest();

		TokenUpdateResponse response = new TokenUpdateResponse();
		TokenError error = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
		response.setTokenError(error);


		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)))
		.andExpect(ResponseMatchers.payload(getSourceFromJAXB(response)));

		assertNull(response.getTokens());
		assertNotNull(response.getTokenError());


	}

	@Test
	public void valid_update_response_test() throws Exception {
		TokenUpdateRequest request = new TokenUpdateRequest();
		request.setTokenCommonRequest(setTokenCommonRequest("T"));

		TokenUpdateResponse response = new TokenUpdateResponse();
		TokenError error = TokenHelper.createTokenError(TokenErrorEnum.API_ERROR);
		response.setTokenError(error);
		
		Map<String, String> namespaces = new HashMap<>();
		namespaces.put("ns2","http://adcb.com/MDES-CS/client/token/update/res");
		
		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)
				)) .andExpect(ResponseMatchers
						.xpath("/ns2:TokenUpdateResponse/ns2:TokenError",namespaces)
						.exists()); 
	}


	@Test
	public void invalid_suspend_response_test() throws Exception {
		TokenSuspendRequest request = new TokenSuspendRequest();


		TokenSuspendResponse response = new TokenSuspendResponse();
		TokenError error = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
		response.setTokenError(error);


		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)))
		.andExpect(ResponseMatchers.payload(getSourceFromJAXB(response)));

		assertNull(response.getToken());
		assertNotNull(response.getTokenError());

	}




	@Test
	public void valid_suspend_response_test() throws Exception {
		TokenSuspendRequest request = new TokenSuspendRequest();
		request.setTokenCommonRequest(setTokenCommonRequest("T"));

		Map<String, String> namespaces = new HashMap<>();
		namespaces.put("ns3","http://adcb.com/MDES-CS/client/token/suspend/res");
		namespaces.put("ns2","http://adcb.com/MDES-CS/client/token/common");
		
		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)
				)) .andExpect(ResponseMatchers
						.xpath("/ns3:TokenSuspendResponse/ns3:Token/ns2:TokenUniqueReference/text()",namespaces)
						.evaluatesTo("DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c")); 
						

	}

	@Test
	public void invalid_unsuspend_response_test() throws Exception {
		TokenUnsuspendRequest request = new TokenUnsuspendRequest();		

		TokenUnsuspendResponse response = new TokenUnsuspendResponse();
		TokenError error = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
		response.setTokenError(error);


		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)))
		.andExpect(ResponseMatchers.payload(getSourceFromJAXB(response)));

		assertNull(response.getToken());
		assertNotNull(response.getTokenError());

	}




	@Test
	public void valid_unsuspend_response_test() throws Exception {
		TokenUnsuspendRequest request = new TokenUnsuspendRequest();
		request.setTokenCommonRequest(setTokenCommonRequest("T"));

		Map<String, String> namespaces = new HashMap<>();
		namespaces.put("ns3","http://adcb.com/MDES-CS/client/token/unsuspend/res");
		namespaces.put("ns2","http://adcb.com/MDES-CS/client/token/common");
		
		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)
				)) .andExpect(ResponseMatchers
						.xpath("/ns3:TokenUnsuspendResponse/ns3:Token/ns2:TokenUniqueReference/text()",namespaces)
						.evaluatesTo("DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c"));
	}

	@Test
	public void invalid_delete_response_test() throws Exception {
		TokenDeleteRequest request = new TokenDeleteRequest();		

		TokenDeleteResponse response = new TokenDeleteResponse();
		TokenError error = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
		response.setTokenError(error);


		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)))
		.andExpect(ResponseMatchers.payload(getSourceFromJAXB(response)));

		assertNull(response.getToken());
		assertNotNull(response.getTokenError());


	}




	@Test
	public void valid_delete_response_test() throws Exception {
		TokenDeleteRequest request = new TokenDeleteRequest();
		request.setTokenCommonRequest(setTokenCommonRequest("T"));

		Map<String, String> namespaces = new HashMap<>();
		namespaces.put("ns3","http://adcb.com/MDES-CS/client/token/delete/res");
		namespaces.put("ns2","http://adcb.com/MDES-CS/client/token/common");
		
		mockClient.sendRequest(RequestCreators.withPayload(getSourceFromJAXB(request)
				)) .andExpect(ResponseMatchers
						.xpath("/ns3:TokenDeleteResponse/ns3:Token/ns2:TokenUniqueReference/text()",namespaces)
						.evaluatesTo("DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c"));
	}

	private AuditInfo setAuditInfo() {
		AuditInfo auditInfo = new AuditInfo();
		auditInfo.setUserId("A1435477");
		auditInfo.setUserName("John Smith");
		auditInfo.setOrganization("Solid Bank Inc");

		return auditInfo;

	}

	private TokenCommonRequest setTokenCommonRequest(String reasonCode) {
		TokenCommonRequest common = new TokenCommonRequest();
		common.setTokenUniqueReference("DWSPMC00000000010906a349d9ca4eb1a4d53e3c90a11d9c");
		common.setAuditInfo(setAuditInfo());
		common.setReasonCode(reasonCode);
		return common;
	}

	private Source getSourceFromJAXB(Object jaxbObject) throws Exception {
		return new JAXBSource(JAXBContext.newInstance(jaxbObject.getClass()), jaxbObject);
	}

	@Before
	public void masterCardApiConfig() {		
		String consumerKey = tokenServiceProps.getConsumerKey();   // You should copy this from "My Keys" on your project page e.g. UTfbhDCSeNYvJpLL5l028sWL9it739PYh6LU5lZja15xcRpY!fd209e6c579dc9d7be52da93d35ae6b6c167c174690b72fa
		String keyAlias =  tokenServiceProps.getKeyAlias();   // For production: change this to the key alias you chose when you created your production key
		String keyPassword = tokenServiceProps.getKeyPassword();   // For production: change this to the key alias you chose when you created your production key
		InputStream is = null;
		try {
			is = new ClassPathResource(tokenServiceProps.getCertName()).getInputStream(); 
		}
		catch(IOException e) {
		}


		try{
			keyPassword = encryption.decrypt(tokenServiceProps.getKeyPassword());
		}catch(Exception e){
			System.out.println("error decrypting card number : "+e.getMessage());
		}


		ApiConfig.setAuthentication(new OAuthAuthentication(consumerKey, is, keyAlias, keyPassword));   // You only need to set this once
		ApiConfig.setDebug(tokenServiceProps.isDebugMode());   // Enable http wire logging
		ApiConfig.setSandbox(tokenServiceProps.isSandboxMode()); // For production: use ApiConfig.setSandbox(false);

	}

	@Before
	public void jacksonApiConfig() {
		TokenUtils.objectMapper
		.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
		.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);

	}


}

