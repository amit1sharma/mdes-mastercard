package com.adcb.mdes_cs.vo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@Component
@ConfigurationProperties(prefix = "mdes.token")
@Getter @Setter @NoArgsConstructor
public class MdesTokenProps {

	private String keyAlias;
	private String keyPassword;
	private boolean sandboxMode;
	private String cryptoKey;
	private String consumerKey;
	private String certName;
	private boolean debugMode;
	
}
