package com.adcb.mdes_cs.helper;


import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;

import com.adcb.mdes_cs.client.token.modify.activate.req.TokenActivateRequest;
import com.adcb.mdes_cs.client.token.modify.activate.res.TokenActivateResponse;
import com.adcb.mdes_cs.client.token.modify.common.AuditInfo;
import com.adcb.mdes_cs.client.token.modify.common.TokenCommonRequest;
import com.adcb.mdes_cs.client.token.modify.common.TokenError;
import com.adcb.mdes_cs.client.token.modify.delete.req.TokenDeleteRequest;
import com.adcb.mdes_cs.client.token.modify.delete.res.TokenDeleteResponse;
import com.adcb.mdes_cs.client.token.modify.suspend.req.TokenSuspendRequest;
import com.adcb.mdes_cs.client.token.modify.suspend.res.TokenSuspendResponse;
import com.adcb.mdes_cs.client.token.modify.unsuspend.req.TokenUnsuspendRequest;
import com.adcb.mdes_cs.client.token.modify.unsuspend.res.TokenUnsuspendResponse;
import com.adcb.mdes_cs.client.token.modify.update.req.CurrentFinancialAccountInformation;
import com.adcb.mdes_cs.client.token.modify.update.req.TokenUpdateRequest;
import com.adcb.mdes_cs.client.token.modify.update.res.TokenUpdateResponse;
import com.adcb.mdes_cs.client.token.search.req.SearchRequest;
import com.adcb.mdes_cs.client.token.search.res.SearchResponse;
import com.adcb.mdes_cs.constants.TokenErrorEnum;
import com.adcb.mdes_cs.constants.TokenRequestTypeEnum;
import com.adcb.mdes_cs.model.TokenServiceReqResLog;
import com.adcb.mdes_cs.util.TokenUtils;
import com.mastercard.api.core.model.RequestMap;
import com.mastercard.api.mdescustomerservice.Search;
import com.mastercard.api.mdescustomerservice.TokenActivate;
import com.mastercard.api.mdescustomerservice.TokenDelete;
import com.mastercard.api.mdescustomerservice.TokenSuspend;
import com.mastercard.api.mdescustomerservice.TokenUnsuspend;
import com.mastercard.api.mdescustomerservice.TokenUpdate;

public class TokenHelper {

	private static final Logger logger = LogManager.getLogger(TokenHelper.class);

	private TokenHelper() {
		throw new IllegalStateException("Helper class");
	}

	public static RequestMap prepareRequest(SearchRequest searchRequest) {
		RequestMap requestMap = null;
		if(TokenUtils.hasMandatorySearchFields(searchRequest)) {

			logger.debug("validation success for search request");

			requestMap = new RequestMap();
			if(StringUtils.isNotBlank(searchRequest.getAccountPan()) ) {
					/*&& 
					StringUtils.isNumeric(searchRequest.getAccountPan())) {*/
				requestMap.set("SearchRequest.AccountPan", searchRequest.getAccountPan());
			}
			else if(StringUtils.isNotBlank(searchRequest.getTokenUniqueReference())) {
				requestMap.set("SearchRequest.TokenUniqueReference", searchRequest.getTokenUniqueReference());
			}
			else if(StringUtils.isNotBlank(searchRequest.getToken())) {
				requestMap.set("SearchRequest.Token", searchRequest.getToken());
			}
			else if(StringUtils.isNotBlank(searchRequest.getPaymentAppInstanceId())) {
				requestMap.set("SearchRequest.PaymentAppInstanceId", searchRequest.getPaymentAppInstanceId());
			}
			else if(StringUtils.isNotBlank(searchRequest.getCommentId())) {
				requestMap.set("SearchRequest.CommentId", searchRequest.getCommentId());
			}
			else if(StringUtils.isNotBlank(searchRequest.getAlternateAccountIdentifier())) {
				requestMap.set("SearchRequest.AlternateAccountIdentifier", searchRequest.getAlternateAccountIdentifier());
			}

			addToRequestMap(requestMap,"SearchRequest.ExcludeDeletedIndicator",searchRequest.getExcludeDeletedIndicator());
			addToRequestMap(requestMap,"SearchRequest.FinancialAccountInformation",searchRequest.getFinancialAccountInformation());

			setAuditInfo(requestMap,searchRequest.getAuditInfo(), TokenRequestTypeEnum.SEARCH_REQUEST);

		}
		return requestMap;
	}

	public static RequestMap prepareRequest(TokenActivateRequest activateRequest) {
		RequestMap requestMap = null;
		TokenCommonRequest tokenCommonRequest = null;
		if(TokenUtils.hasMandatoryTokenActivateFields(activateRequest)) {

			logger.debug("validation success for activate request");

			requestMap = new RequestMap();
			if(null != activateRequest.getTokenCommonRequest()) {

				tokenCommonRequest = activateRequest.getTokenCommonRequest();
				setTokenCommonRequest(requestMap, tokenCommonRequest, TokenRequestTypeEnum.ACTIVATE_REQUEST);

				if(null != tokenCommonRequest && StringUtils.isBlank(tokenCommonRequest.getTokenUniqueReference()) && 
						(StringUtils.isNotBlank(activateRequest.getAccountPan()) &&
								StringUtils.isNotBlank(activateRequest.getPaymentAppInstanceId()))) {
					requestMap.set("TokenActivateRequest.AccountPan", activateRequest.getAccountPan());
					requestMap.set("TokenActivateRequest.PaymentAppInstanceId", activateRequest.getPaymentAppInstanceId());
				}
			}

		}
		return requestMap;
	}

	public static RequestMap prepareRequest(Object request) {
		RequestMap requestMap = null;
		if(TokenUtils.hasMandatoryTokenModFields(request)) {
			requestMap = new RequestMap();

			TokenCommonRequest tokenCommonRequest = null;
			TokenRequestTypeEnum requestTypeIdentifier = null;
			if(request instanceof TokenSuspendRequest) {

				logger.debug("validation success for suspend request");

				TokenSuspendRequest suspendRequest = (TokenSuspendRequest) request;
				tokenCommonRequest = suspendRequest.getTokenCommonRequest();
				requestTypeIdentifier = TokenRequestTypeEnum.SUSPEND_REQUEST;
			}
			else if(request instanceof TokenUnsuspendRequest) {

				logger.debug("validation success for unsuspend request");

				TokenUnsuspendRequest unsuspendRequest = (TokenUnsuspendRequest) request;
				tokenCommonRequest = unsuspendRequest.getTokenCommonRequest();
				requestTypeIdentifier = TokenRequestTypeEnum.UNSUSPEND_REQUEST;
			}
			else if(request instanceof TokenDeleteRequest) {

				logger.debug("validation success for delete request");

				TokenDeleteRequest deleteRequest = (TokenDeleteRequest) request;
				tokenCommonRequest = deleteRequest.getTokenCommonRequest();
				requestTypeIdentifier = TokenRequestTypeEnum.DELETE_REQUEST;
			}

			if(null != tokenCommonRequest && null != requestTypeIdentifier) {
				setTokenCommonRequest(requestMap, tokenCommonRequest, requestTypeIdentifier);
			}
		}

		return requestMap;
	}

	public static RequestMap prepareRequest(TokenUpdateRequest updateRequest) {
		RequestMap requestMap = null;
		if(null != updateRequest && null != updateRequest.getTokenCommonRequest()) { 
				// && null != updateRequest.getTokenCommonRequest().getAuditInfo()) 
				//&& TokenUtils.hasMandatoryTokenAuditFields(updateRequest.getTokenCommonRequest().getAuditInfo())) {

			logger.debug("mandatory audit fields success for update request");

			requestMap = new RequestMap();

			if(null != updateRequest.getTokenCommonRequest()) {
				setTokenCommonRequest(requestMap, updateRequest.getTokenCommonRequest(), TokenRequestTypeEnum.UPDATE_REQUEST);
			}
			addToRequestMap(requestMap, "TokenUpdateRequest.CurrentAccountPan", updateRequest.getCurrentAccountPan());
			addToRequestMap(requestMap, "TokenUpdateRequest.NewAccountPan", updateRequest.getNewAccountPan());

			if(null != updateRequest.getCurrentFinancialAccountInformation()) {
				setCurrentFinancialInformation(requestMap, updateRequest.getCurrentFinancialAccountInformation(), TokenRequestTypeEnum.UPDATE_REQUEST);	
			}

			addToRequestMap(requestMap, "TokenUpdateRequest.NewFinancialAccountId", updateRequest.getNewFinancialAccountId());
			addToRequestMap(requestMap, "TokenUpdateRequest.ExpirationDate", updateRequest.getExpirationDate());
			addToRequestMap(requestMap, "TokenUpdateRequest.AccountPanSequenceNumber", updateRequest.getAccountPanSequenceNumber());
			addToRequestMap(requestMap, "TokenUpdateRequest.IssuerProductConfigurationId", updateRequest.getIssuerProductConfigurationId());
			addToRequestMap(requestMap, "TokenUpdateRequest.UpdateWalletProviderIndicator", updateRequest.getUpdateWalletProviderIndicator());

		}
		return requestMap;
	}



	private static void setTokenCommonRequest(RequestMap requestMap, TokenCommonRequest tokenCommonRequest, TokenRequestTypeEnum requestTypeIdentifier) {
		if(null != tokenCommonRequest) {
			addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".TokenUniqueReference", tokenCommonRequest.getTokenUniqueReference());
			addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".ReasonCode", tokenCommonRequest.getReasonCode());
			setAuditInfo(requestMap, tokenCommonRequest.getAuditInfo(), requestTypeIdentifier);
			addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".CommentText", tokenCommonRequest.getCommentText());
		}
	}

	private static void setCurrentFinancialInformation(RequestMap requestMap, CurrentFinancialAccountInformation currFinancialAccInfo, TokenRequestTypeEnum requestTypeIdentifier) {
		if(null != currFinancialAccInfo) {
			addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".FinancialAccountId", currFinancialAccInfo.getFinancialAccountId());
			addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".InterbankCardAssociationId", currFinancialAccInfo.getInterbankCardAssociationId());
			addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".CountryCode", currFinancialAccInfo.getCountryCode());
		}
	}

	public static SearchResponse prepareResponse(Search searchToken) {

		JSONObject obj = null;
		SearchResponse response = new SearchResponse();

		if(null != searchToken.get("SearchResponse")) {
			obj = (JSONObject) searchToken.get("SearchResponse");
		}
		else {
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR);
			response.setTokenError(error);
			return response;
		}

		try {
			response = TokenUtils.objectMapper.
					readValue(obj.toJSONString(), SearchResponse.class);
		} 
		/*
		 * catch (JsonParseException | JsonMappingException jsonException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * jsonException.toString()); response.setTokenError(error); } catch
		 * (IOException ioException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * ioException.toString()); response.setTokenError(error); }
		 */
		catch (Exception exception) {
			logger.error("Exception while mapping mastercard response JSON to SearchResponse Object", exception);
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR, exception.toString());
			response.setTokenError(error);
		}

		return response;
	}

	public static TokenActivateResponse prepareResponse(TokenActivate activateToken) {

		JSONObject obj = null;
		TokenActivateResponse response = new TokenActivateResponse();

		if(null != activateToken.get("TokenActivateResponse")) {
			obj = (JSONObject) activateToken.get("TokenActivateResponse");
		}
		else {
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR);
			response.setTokenError(error);
			return response;
		}

		try {
			response = TokenUtils.objectMapper.
					readValue(obj.toJSONString(), TokenActivateResponse.class);
		} 
		/*
		 * catch (JsonParseException | JsonMappingException jsonException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * jsonException.toString()); response.setTokenError(error); } catch
		 * (IOException ioException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * ioException.toString()); response.setTokenError(error); }
		 */
		catch (Exception exception) {
			logger.error("Exception while mapping mastercard response JSON to TokenActivateResponse Object", exception);
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR, exception.toString());
			response.setTokenError(error);
		}

		return response;
	}



	public static TokenUpdateResponse prepareResponse(TokenUpdate updateToken) {

		JSONObject obj = null;
		TokenUpdateResponse response = new TokenUpdateResponse();

		if(null != updateToken.get("TokenUpdateResponse")) {
			obj = (JSONObject) updateToken.get("TokenUpdateResponse");
		}
		else {
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR);
			response.setTokenError(error);
			return response;
		}

		try {
			response = TokenUtils.objectMapper.
					readValue(obj.toJSONString(), TokenUpdateResponse.class);
		} 
		/*
		 * catch (JsonParseException | JsonMappingException jsonException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * jsonException.toString()); response.setTokenError(error); } catch
		 * (IOException ioException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * ioException.toString()); response.setTokenError(error); }
		 */
		catch (Exception exception) {
			logger.error("Exception while mapping mastercard response JSON to TokenUpdateResponse Object", exception);
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR, exception.toString());
			response.setTokenError(error);
		}

		return response;
	}

	public static TokenSuspendResponse prepareResponse(TokenSuspend suspendToken) {

		JSONObject obj = null;
		TokenSuspendResponse response = new TokenSuspendResponse();

		if(null != suspendToken.get("TokenSuspendResponse")) {
			obj = (JSONObject) suspendToken.get("TokenSuspendResponse");
		}
		else {
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR);
			response.setTokenError(error);
			return response;
		}

		try {
			response = TokenUtils.objectMapper.
					readValue(obj.toJSONString(), TokenSuspendResponse.class);
		} 
		/*
		 * catch (JsonParseException | JsonMappingException jsonException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * jsonException.toString()); response.setTokenError(error); } catch
		 * (IOException ioException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * ioException.toString()); response.setTokenError(error); }
		 */
		catch (Exception exception) {
			logger.error("Exception while mapping mastercard response JSON to TokenSuspendResponse Object", exception);
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR, exception.toString());
			response.setTokenError(error);
		}

		return response;
	}

	public static TokenUnsuspendResponse prepareResponse(TokenUnsuspend unsuspendToken) {

		JSONObject obj = null;
		TokenUnsuspendResponse response = new TokenUnsuspendResponse();

		if(null != unsuspendToken.get("TokenUnsuspendResponse")) {
			obj = (JSONObject) unsuspendToken.get("TokenUnsuspendResponse");
		}
		else {
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR);
			response.setTokenError(error);
			return response;
		}

		try {
			response = TokenUtils.objectMapper.
					readValue(obj.toJSONString(), TokenUnsuspendResponse.class);
		} 
		/*
		 * catch (JsonParseException | JsonMappingException jsonException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * jsonException.toString()); response.setTokenError(error); } catch
		 * (IOException ioException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * ioException.toString()); response.setTokenError(error); }
		 */
		catch (Exception exception) {
			logger.error("Exception while mapping mastercard response JSON to TokenUnsuspendResponse Object", exception);
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR, exception.toString());
			response.setTokenError(error);
		}

		return response;
	}

	public static TokenDeleteResponse prepareResponse(TokenDelete deleteToken) {

		JSONObject obj = null;
		TokenDeleteResponse response = new TokenDeleteResponse();

		if(null != deleteToken.get("TokenDeleteResponse")) {
			obj = (JSONObject) deleteToken.get("TokenDeleteResponse");
		}
		else {
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR);
			response.setTokenError(error);
			return response;
		}

		try {
			response = TokenUtils.objectMapper.
					readValue(obj.toJSONString(), TokenDeleteResponse.class);
		} 
		/*
		 * catch (JsonParseException | JsonMappingException jsonException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * jsonException.toString()); response.setTokenError(error); } catch
		 * (IOException ioException) {
		 * 
		 * TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR,
		 * ioException.toString()); response.setTokenError(error); }
		 */
		catch (Exception exception) {
			logger.error("Exception while mapping mastercard response JSON to TokenDeleteResponse Object", exception);
			TokenError error = createTokenError(TokenErrorEnum.GENERIC_ERROR, exception.toString());
			response.setTokenError(error);
		}

		return response;
	}

	private static void setAuditInfo(RequestMap requestMap, AuditInfo auditInfo, TokenRequestTypeEnum requestTypeIdentifier) {
		if(null != auditInfo) {
			if(TokenUtils.hasMandatoryTokenAuditFields(auditInfo)) {
				addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".AuditInfo.UserId", auditInfo.getUserId());
				addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".AuditInfo.UserName", auditInfo.getUserName());
				addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".AuditInfo.Organization", auditInfo.getOrganization());
			}
			addToRequestMap(requestMap, requestTypeIdentifier.getFullName() + ".AuditInfo.Phone", auditInfo.getPhone());
		}

	}

	public static TokenError createTokenError(TokenErrorEnum errorObj) {
		return createTokenError(errorObj, null);
	}

	public static TokenError createTokenError(TokenErrorEnum errorObj, String message) {
		TokenError error =  new TokenError();
		error.setErrorCode(errorObj.getCode());
		if(StringUtils.isNotBlank(message)) {
			error.setErrorDesc(message);	
		}
		else {
			error.setErrorDesc(errorObj.getMessage());
		}

		return error;
	}

	public static TokenServiceReqResLog prepareTokenLog(RequestMap requestMap, 
			String requestStr, 
			Date requestTime,
			TokenRequestTypeEnum requestTypeIdentifier, 
			String responseStr, 
			Date responseTime,
			String sysRefNo) {
		TokenServiceReqResLog tokenReqResLog = new TokenServiceReqResLog();
		try {
			tokenReqResLog.setReqTimeStamp(requestTime);
			tokenReqResLog.setRespTimeStamp(responseTime);
			tokenReqResLog.setRequestDataOrig(requestStr);
			tokenReqResLog.setResponseData(responseStr);
			tokenReqResLog.setServiceName(requestTypeIdentifier.getFullName());
			tokenReqResLog.setSysRefNo(sysRefNo);
			
			if(null != requestMap) {

				if(null != requestMap.get(requestTypeIdentifier.getFullName())) {
					tokenReqResLog.setRequestDataVendor(requestMap.get(requestTypeIdentifier.getFullName()).toString());
				}
				Object tokenUniqueReference = requestMap.get(requestTypeIdentifier.getFullName() + ".TokenUniqueReference");
				if(null != tokenUniqueReference && StringUtils.isNotBlank(tokenUniqueReference.toString())) {
					tokenReqResLog.setTokenUniqueReference(tokenUniqueReference.toString());
				}
				Object token = requestMap.get(requestTypeIdentifier.getFullName() + ".Token");
				if(null != token && StringUtils.isNotBlank(token.toString())) {
					tokenReqResLog.setToken(token.toString());				
				}
				Object accountPan = requestMap.get(requestTypeIdentifier.getFullName() + ".AccountPan");
				if(null != accountPan && StringUtils.isNotBlank(accountPan.toString())) {
					tokenReqResLog.setAccountPan(accountPan.toString());
				}
				Object currAccountPan = requestMap.get(requestTypeIdentifier.getFullName() + ".CurrentAccountPan");
				if(null != currAccountPan && StringUtils.isNotBlank(currAccountPan.toString())) {
					tokenReqResLog.setAccountPan(currAccountPan.toString());
				}
			}
		}
		catch(Exception exception) {
			logger.error("Error while preparing logging information for token service",exception);
		}

		return tokenReqResLog;
	}

	private static void addToRequestMap(RequestMap requestMap, String key, String value) {
		if(null != requestMap && StringUtils.isNotBlank(value)) {
			requestMap.set(key, value);
		}

	}



}
