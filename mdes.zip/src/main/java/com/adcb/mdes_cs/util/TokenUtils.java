package com.adcb.mdes_cs.util;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.adcb.mdes_cs.client.token.modify.activate.req.TokenActivateRequest;
import com.adcb.mdes_cs.client.token.modify.common.AuditInfo;
import com.adcb.mdes_cs.client.token.modify.common.Header;
import com.adcb.mdes_cs.client.token.modify.common.TokenCommonRequest;
import com.adcb.mdes_cs.client.token.modify.delete.req.TokenDeleteRequest;
import com.adcb.mdes_cs.client.token.modify.suspend.req.TokenSuspendRequest;
import com.adcb.mdes_cs.client.token.modify.unsuspend.req.TokenUnsuspendRequest;
import com.adcb.mdes_cs.client.token.search.req.SearchRequest;
import com.adcb.mdes_cs.endpoint.TokenServiceEndpoint;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

public class TokenUtils {
	
	public static final XmlMapper xmlMapper =	new XmlMapper();
	public static final ObjectMapper objectMapper =	new ObjectMapper();
	
	private static final Logger logger = LogManager.getLogger(TokenUtils.class);
	
	private TokenUtils() {
		throw new IllegalStateException("Utility class");
	}
	
	public static boolean hasMandatorySearchFields(SearchRequest searchRequest) {
		return (null != searchRequest); 
		/*
		 * && (StringUtils.hasText(searchRequest.getAccountPan()) ||
		 * StringUtils.hasText(searchRequest.getTokenUniqueReference()) ||
		 * StringUtils.hasText(searchRequest.getToken()) ||
		 * StringUtils.hasText(searchRequest.getPaymentAppInstanceId()) ||
		 * StringUtils.hasText(searchRequest.getCommentId()) ||
		 * StringUtils.hasText(searchRequest.getAlternateAccountIdentifier())) &&
		 * (hasMandatoryTokenAuditFields(searchRequest.getAuditInfo()))) ;
		 */
			
	}

	public static boolean hasMandatoryTokenAuditFields(AuditInfo auditInfo) {
		return (null !=auditInfo );
				/*&&
				StringUtils.hasText(auditInfo.getUserId()) && 
				StringUtils.hasText(auditInfo.getUserName()) && 
				StringUtils.hasText(auditInfo.getOrganization()));*/
	}

	public static boolean hasMandatoryTokenModFields(Object request) {
		if(null != request) {
			TokenCommonRequest tokenCommonRequest = null;
			if(request instanceof TokenSuspendRequest) {
				TokenSuspendRequest suspendRequest = (TokenSuspendRequest) request;
				tokenCommonRequest = suspendRequest.getTokenCommonRequest();
			}
			else if(request instanceof TokenUnsuspendRequest) {
				TokenUnsuspendRequest unsuspendRequest = (TokenUnsuspendRequest) request;
				tokenCommonRequest = unsuspendRequest.getTokenCommonRequest();
			}
			else if(request instanceof TokenDeleteRequest) {
				TokenDeleteRequest deleteRequest = (TokenDeleteRequest) request;
				tokenCommonRequest = deleteRequest.getTokenCommonRequest();
			}
			
			if(null != tokenCommonRequest) {
				return hasMandatoryTokenCmnFields(tokenCommonRequest);
			}
		}
			
		return false;
	}

	private static boolean hasMandatoryTokenCmnFields(TokenCommonRequest tokenCommonRequest) {
			return (null != tokenCommonRequest);
					/*&& StringUtils.hasText(tokenCommonRequest.getTokenUniqueReference()) &&
					StringUtils.hasText(tokenCommonRequest.getReasonCode()) && 
					hasMandatoryTokenAuditFields(tokenCommonRequest.getAuditInfo()));*/
	}

	public static boolean hasMandatoryTokenActivateFields(TokenActivateRequest activateRequest) {
		if(null != activateRequest && null != activateRequest.getTokenCommonRequest()) {
			return true;
			/*
			 * TokenCommonRequest commonRequest = activateRequest.getTokenCommonRequest();
			 * if((StringUtils.hasText(commonRequest.getTokenUniqueReference()) ||
			 * (StringUtils.hasText(activateRequest.getAccountPan()) &&
			 * StringUtils.hasText(activateRequest.getPaymentAppInstanceId()))) &&
			 * StringUtils.hasText(commonRequest.getReasonCode()) &&
			 * hasMandatoryTokenAuditFields(commonRequest.getAuditInfo())) { return true; }
			 */
		}
		return false;
	}

	public static String getSysRefNo(Object request) {
		String sysRefNo = null;
		try {
			if(null != request) {
				Header header = null;
				if(request instanceof SearchRequest) {
					SearchRequest search = (SearchRequest) request;
					header = search.getHeader();
				}
				else if(request instanceof TokenCommonRequest) {
					TokenCommonRequest common = (TokenCommonRequest) request;
					header = common.getHeader();
				}
				if(null != header) {
					sysRefNo = header.getSystemRefNo();	
				}
			}
		}
		catch(Exception e) {
			logger.error("Error while fetching system reference number from request", e);
		}
		
		return sysRefNo;
	}

}
