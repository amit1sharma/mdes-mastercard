package com.adcb.mdes_cs.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter @Setter @NoArgsConstructor
@Entity
@Table(name = "MDES_TOKEN_REQ_RES")
public class TokenServiceReqResLog {

	@Id
	@Column(name = "REQID")
	@GeneratedValue
	private Long requestId;
	
	@Column(name = "SYS_REF_NO")
	private String sysRefNo;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REQTIMESTAMP")
	private Date reqTimeStamp;
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "RESPTIMESTAMP")
	private Date respTimeStamp;
	
	@Lob
	@Column(name = "REQUESTDATA_TIBCO")
	private String requestDataOrig;
	
	@Lob
	@Column(name = "REQUESTDATA_VENDOR")
	private String requestDataVendor;
	
	@Lob
	@Column(name = "RESPONSEDATA")
	private String responseData;
	
	@Column(name = "SERVICE_NAME")
	private String serviceName;
	
	@Column(name = "TOKEN_REF")
	private String tokenUniqueReference;
	
	@Column(name = "TOKEN_NUM")
	private String token;
	
	@Column(name = "ACCOUNT_PAN_NO")
	private String accountPan;
	 
}