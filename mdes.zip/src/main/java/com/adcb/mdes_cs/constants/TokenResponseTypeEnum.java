package com.adcb.mdes_cs.constants;

public enum TokenResponseTypeEnum {

	SEARCH_RESPONSE("SearchResponse"),
	SUSPEND_RESPONSE("TokenSuspendResponse"), 
	UPDATE_RESPONSE("TokenUpdateResponse"), 
	ACTIVATE_RESPONSE("TokenActivateResponse"), 
	UNSUSPEND_RESPONSE("TokenUnsuspendResponse"), 
	DELETE_RESPONSE("TokenDeleteResponse");
	
	
	String fullName;
	
	TokenResponseTypeEnum(String fullName){
		this.fullName = fullName;
	}
	
	public String getFullName() {
		return fullName;
	}
}
