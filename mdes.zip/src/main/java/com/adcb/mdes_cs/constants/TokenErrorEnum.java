package com.adcb.mdes_cs.constants;

public enum TokenErrorEnum {

	SUCCESS("0", "Success"),
	GENERIC_ERROR("1", "There is an internal error. Please try again later"),
	VALIDATION_ERROR("3", "Validation failed. Please check the request."),
	API_ERROR("4", "There has been an error from the vendor"),
	REASON_CODE_ERROR("5","Please enter a valid message reason code");
	
	
	String code;
	String message;
	
	TokenErrorEnum(String code, String message){
		this.code = code;
		this.message = message;
	}
	
	public String getCode() {
		return code;
	}
	
	public String getMessage() {
		return message;
	}
}
