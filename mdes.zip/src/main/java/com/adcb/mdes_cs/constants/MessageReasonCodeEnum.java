package com.adcb.mdes_cs.constants;

public enum MessageReasonCodeEnum {

	SEARCH,
	SUSPEND, 
	UPDATE, 
	CALL_CENTER_ACTIVATION, 
	RESUME, 
	DELETE;
	
}
