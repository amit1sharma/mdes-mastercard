package com.adcb.mdes_cs.constants;

public enum TokenRequestTypeEnum {

	SEARCH_REQUEST("SearchRequest"),
	SUSPEND_REQUEST("TokenSuspendRequest"), 
	UPDATE_REQUEST("TokenUpdateRequest"), 
	ACTIVATE_REQUEST("TokenActivateRequest"), 
	UNSUSPEND_REQUEST("TokenUnsuspendRequest"), 
	DELETE_REQUEST("TokenDeleteRequest");
	
	
	String fullName;
	
	TokenRequestTypeEnum(String fullName){
		this.fullName = fullName;
	}
	
	public String getFullName() {
		return fullName;
	}
}
