package com.adcb.mdes_cs.config;

import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.ws.config.annotation.EnableWs;
import org.springframework.ws.config.annotation.WsConfigurerAdapter;
import org.springframework.ws.transport.http.MessageDispatcherServlet;
import org.springframework.ws.wsdl.wsdl11.SimpleWsdl11Definition;
import org.springframework.xml.xsd.XsdSchemaCollection;
import org.springframework.xml.xsd.commons.CommonsXsdSchemaCollection;

@EnableWs
@Configuration
public class TokenServiceConfig extends WsConfigurerAdapter {
	@Bean
	public ServletRegistrationBean messageDispatcherServlet(ApplicationContext applicationContext) {
		MessageDispatcherServlet servlet = new MessageDispatcherServlet();
		servlet.setApplicationContext(applicationContext);
		servlet.setTransformWsdlLocations(true);
		return new ServletRegistrationBean(servlet, "/ws/*");
	}




	/*
	 * @Bean(name = "MDES_CIS_Token_Service") public DefaultWsdl11Definition
	 * searchWsdl11Definition(XsdSchemaCollection searchSchema) {
	 * DefaultWsdl11Definition wsdl11Definition = new DefaultWsdl11Definition();
	 * wsdl11Definition.setPortTypeName("TokenServicePort");
	 * wsdl11Definition.setLocationUri("/ws");
	 * wsdl11Definition.setTargetNamespace("http://adcb.com/MDES-CS/client/token");
	 * wsdl11Definition.setSchemaCollection(searchSchema); return wsdl11Definition;
	 * }
	 */

	@Bean(name = "MDES_CIS_Token_Service") 
	public SimpleWsdl11Definition simpleWsdl11Definition() { 
		SimpleWsdl11Definition simpleWsdl11Definition = new SimpleWsdl11Definition(); 
		simpleWsdl11Definition.setWsdl(new ClassPathResource("wsdl/MDES_CIS_Token_Service.wsdl"));
		return simpleWsdl11Definition; 
	}



	@Bean
	public XsdSchemaCollection searchSchema() {
		CommonsXsdSchemaCollection xsds = new CommonsXsdSchemaCollection(
				new ClassPathResource("/xsds/TokenService.xsd"));
		xsds.setInline(true);
		return xsds;
	}
}