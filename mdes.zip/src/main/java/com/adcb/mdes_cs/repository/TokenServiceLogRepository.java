package com.adcb.mdes_cs.repository;

import org.springframework.data.repository.CrudRepository;

import com.adcb.mdes_cs.model.TokenServiceReqResLog;

public interface TokenServiceLogRepository extends CrudRepository<TokenServiceReqResLog, Long>{
	
	

}
