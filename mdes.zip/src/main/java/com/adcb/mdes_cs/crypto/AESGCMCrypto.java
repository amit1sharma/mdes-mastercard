package com.adcb.mdes_cs.crypto;

import java.nio.ByteBuffer;
import java.security.SecureRandom;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;


@Component
public class AESGCMCrypto {

	@Value("${mdes.token.cryptoKey}")
	private String encryptionKey;
	
	public String encrypt(String textToEncrypt) throws Exception{
		return encrypt(textToEncrypt, encryptionKey);
	}
	
	public String decrypt(String encryptedString) throws Exception{
		return decrypt(encryptedString, encryptionKey);
	}
	
	public String encrypt(String textToEncrypt, String passkey) throws Exception{
		SecureRandom secureRandom = new SecureRandom();
		byte[] key = passkey.getBytes();
		SecretKey secretKey = new SecretKeySpec(key, "AES");
		
		byte[] iv = new byte[12];
		secureRandom.nextBytes(iv);
		
		final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
		GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv); //128 bit auth tag length
		cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);
			
		byte[] cipherText = cipher.doFinal(textToEncrypt.getBytes());
		ByteBuffer byteBuffer = ByteBuffer.allocate(4 + iv.length + cipherText.length);
		byteBuffer.putInt(iv.length);
		byteBuffer.put(iv);
		byteBuffer.put(cipherText);
		byte[] cipherMessage = byteBuffer.array();
		return Base64.getEncoder().encodeToString(cipherMessage);

	}
	
	public String decrypt(String encryptedString, String passkey) throws Exception{
		ByteBuffer byteBuffer = ByteBuffer.wrap(Base64.getDecoder().decode(encryptedString));
		
//		ByteBuffer byteBuffer = ByteBuffer.wrap(encryptedString);
		byte[] key = passkey.getBytes();
		int ivLength = byteBuffer.getInt();
		if(ivLength < 12 || ivLength >= 16) { // check input parameter
		    throw new IllegalArgumentException("invalid iv length");
		}
		byte[] iv = new byte[ivLength];
		byteBuffer.get(iv);
		byte[] cipherText = new byte[byteBuffer.remaining()];
		byteBuffer.get(cipherText);
		
		final Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
		cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));

		byte[] plainText= cipher.doFinal(cipherText);
		
		return new String(plainText);
	}
	
	/*
	 * public static void main(String[] args){ try{ AESGCMCrypto obj = new
	 * AESGCMCrypto();
	 * System.out.println(obj.encrypt("keystorepassword","MDESCISADCBTOKEN")); //
	 * System.out.println(obj.decrypt(
	 * "AAAADPvu3dDKt+x+tRyX5p4cc1JVsimvm+sXSyME+D1MNwBXWseLLiKq4gZ5PpX+",
	 * "CLEARTRIP2ADCBTP")); }catch(Exception e ){ e.printStackTrace(); } }
	 */
}
