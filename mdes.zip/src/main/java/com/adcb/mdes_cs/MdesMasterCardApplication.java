package com.adcb.mdes_cs;

import java.io.IOException;
import java.io.InputStream;

import javax.annotation.PostConstruct;

import org.apache.http.HttpHost;
import org.apache.http.impl.client.CustomHttpClientBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;
import org.springframework.core.io.ClassPathResource;

import com.adcb.mdes_cs.crypto.AESGCMCrypto;
import com.adcb.mdes_cs.util.TokenUtils;
import com.adcb.mdes_cs.vo.MdesTokenProps;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.MapperFeature;
import com.mastercard.api.core.ApiConfig;
import com.mastercard.api.core.security.oauth.OAuthAuthentication;

@SpringBootApplication
public class MdesMasterCardApplication extends SpringBootServletInitializer {

	@Autowired
	private AESGCMCrypto encryption;
	
	@Autowired
	private MdesTokenProps tokenServiceProps;
	
	@Value( "${API_GATEWAY_PROXY_IP}" )
	private String apiGatewayProxyIp;
	
	@Value( "${API_GATEWAY_PROXY_PORT}" )
	private int apiGatewayProxyPort;

	@Value( "${API_GATEWAY_PROXY_ENABLED}" )
	private boolean isProxyEnabled;
	
	//changed name to tokenlogger as the same is used in SpringBootServletInitializer - Sonarqube issue
	private static final Logger tokenLogger = LogManager.getLogger(MdesMasterCardApplication.class);
	
	public static void main(String[] args) {
		SpringApplication.run(MdesMasterCardApplication.class, args);
	}

	@PostConstruct
	private void init() {
		tokenLogger.debug("MdesMasterCardApplication init called");
		masterCardApiConfig();
		jacksonApiConfig();
	}

	private void jacksonApiConfig() {
		tokenLogger.debug("MdesMasterCardApplication jacksonApiConfig called");
		TokenUtils.objectMapper
		.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
		.configure(MapperFeature.ACCEPT_CASE_INSENSITIVE_PROPERTIES, true);
		
	}

	private void masterCardApiConfig() {
		tokenLogger.debug("MdesMasterCardApplication masterCardApiConfig called");
		
		String consumerKey = tokenServiceProps.getConsumerKey();
	    String keyAlias =  tokenServiceProps.getKeyAlias();
	    String keyPassword = tokenServiceProps.getKeyPassword();
	    InputStream is = null;
	    try {
	    	 is = new ClassPathResource(tokenServiceProps.getCertName()).getInputStream(); 
	    }
	    catch(IOException e) {
	    	tokenLogger.error("Error while reading the certificate for MDES CIS API",e);
	    }
	    

		try{
			keyPassword = encryption.decrypt(tokenServiceProps.getKeyPassword());
		}catch(Exception e){
			tokenLogger.error("error decrypting card number : " , e);
		}
	
	    
	    ApiConfig.setAuthentication(new OAuthAuthentication(consumerKey, is, keyAlias, keyPassword));
	   	ApiConfig.setDebug(tokenServiceProps.isDebugMode());
	    //use sandbox false for production
	    ApiConfig.setSandbox(tokenServiceProps.isSandboxMode());
	    //for API Gateway proxy
	    if(isProxyEnabled) {
	    	 CustomHttpClientBuilder builder = ApiConfig.getHttpClientBuilder();
	 	    HttpHost proxy = new HttpHost(apiGatewayProxyIp, apiGatewayProxyPort);
	 	    builder.setProxy(proxy);
	    }
	   
	    //ApiConfig.setReverseProxy(apiGatewayProxy); // This will route requests through the specified URL
		
	}
}
