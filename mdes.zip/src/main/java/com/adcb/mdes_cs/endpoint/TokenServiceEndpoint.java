package com.adcb.mdes_cs.endpoint;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import com.adcb.mdes_cs.client.token.modify.activate.req.TokenActivateRequest;
import com.adcb.mdes_cs.client.token.modify.activate.res.TokenActivateResponse;
import com.adcb.mdes_cs.client.token.modify.common.TokenError;
import com.adcb.mdes_cs.client.token.modify.delete.req.TokenDeleteRequest;
import com.adcb.mdes_cs.client.token.modify.delete.res.TokenDeleteResponse;
import com.adcb.mdes_cs.client.token.modify.req.TokenModifyRequest;
import com.adcb.mdes_cs.client.token.modify.res.TokenModifyResponse;
import com.adcb.mdes_cs.client.token.modify.suspend.req.TokenSuspendRequest;
import com.adcb.mdes_cs.client.token.modify.suspend.res.TokenSuspendResponse;
import com.adcb.mdes_cs.client.token.modify.unsuspend.req.TokenUnsuspendRequest;
import com.adcb.mdes_cs.client.token.modify.unsuspend.res.TokenUnsuspendResponse;
import com.adcb.mdes_cs.client.token.modify.update.req.TokenUpdateRequest;
import com.adcb.mdes_cs.client.token.modify.update.res.TokenUpdateResponse;
import com.adcb.mdes_cs.client.token.search.req.SearchRequest;
import com.adcb.mdes_cs.client.token.search.res.SearchResponse;
import com.adcb.mdes_cs.constants.MessageReasonCodeEnum;
import com.adcb.mdes_cs.constants.TokenErrorEnum;
import com.adcb.mdes_cs.constants.TokenRequestTypeEnum;
import com.adcb.mdes_cs.helper.TokenHelper;
import com.adcb.mdes_cs.repository.TokenServiceLogRepository;
import com.adcb.mdes_cs.service.ITokenService;
import com.adcb.mdes_cs.util.TokenUtils;
import com.mastercard.api.core.exception.ApiException;
import com.mastercard.api.core.model.RequestMap;


@Endpoint
public class TokenServiceEndpoint {

	private static final Logger logger = LogManager.getLogger(TokenServiceEndpoint.class);

	private static final String NAMESPACE_URI_TOKEN_SEARCH = "http://adcb.com/MDES-CS/client/token/search/req";
	private static final String NAMESPACE_URI_TOKEN_MODIFY = "http://adcb.com/MDES-CS/client/token/modify/req";


	@Autowired
	private ITokenService tokenService;

	@Autowired 
	private TokenServiceLogRepository tokenLogRepository;


	@PayloadRoot(namespace = NAMESPACE_URI_TOKEN_SEARCH, localPart = "SearchRequest")
	@ResponsePayload
	public SearchResponse searchToken(@RequestPayload SearchRequest request) {
		logger.debug("Inside searchToken");

		SearchResponse response = null;
		RequestMap requestMap = null; 
		Date requestTime = new Date();
		String sysRefNo = null;
		TokenError tokenStatusObj = null;
		
		try {

			requestMap = TokenHelper.prepareRequest(request);
			if(null != requestMap){
				sysRefNo = TokenUtils.getSysRefNo(request);
				response = TokenHelper.prepareResponse(tokenService.searchToken(requestMap));	
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.SUCCESS);	
			}
			else {
				logger.error("Request Map for search request is null");
				response = new SearchResponse();
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);}
		}
		catch(ApiException apiException) {
			logger.error("Api Exception while token search",apiException);
			response = new SearchResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.API_ERROR, apiException.toString());
			
		}
		catch(Exception exception) {
			logger.error("Generic Exception while token search",exception);
			response = new SearchResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.GENERIC_ERROR);
			
		}

		response.setTokenError(tokenStatusObj);
		
		try {
			logger.debug("DB logging for token search");
			tokenLogRepository.save(TokenHelper.prepareTokenLog(requestMap, 
					TokenUtils.xmlMapper.writeValueAsString(request), 
					requestTime, 
					TokenRequestTypeEnum.SEARCH_REQUEST, 
					TokenUtils.objectMapper.writeValueAsString(response), 
					new Date(),
					sysRefNo));
		}

		catch(Exception exception) {
			logger.error("Error while logging DB info for token search",exception);
		}

		return response;
	}

	@PayloadRoot(namespace = NAMESPACE_URI_TOKEN_MODIFY, localPart = "TokenModifyRequest")
	@ResponsePayload
	public TokenModifyResponse modifyToken(@RequestPayload TokenModifyRequest request) {
		logger.debug("Inside modifyToken");

		TokenModifyResponse response = new TokenModifyResponse();


		if(null != request && StringUtils.isNotBlank(request.getMessageReasonCode())) {
			switch(MessageReasonCodeEnum.valueOf(request.getMessageReasonCode())) {
			case CALL_CENTER_ACTIVATION:
				response.setActivateResponse(activateToken(request.getActivateRequest()));
				break;
			case UPDATE:
				response.setUpdateResponse(updateToken(request.getUpdateRequest()));
				break;
			case DELETE:
				response.setDeleteResponse(deleteToken(request.getDeleteRequest()));
				break;
			case SUSPEND:
				response.setSuspendResponse(suspendToken(request.getSuspendRequest()));
				break;
			case RESUME:
				response.setUnsuspendResponse(unsuspendToken(request.getUnsuspendRequest()));
				break;
			default:
				break;
			}
			response.setMessageReasonCode(request.getMessageReasonCode());
		}

		//No try catch block as there is no TokenError in Modify Request as per TIBCO's requirement
		return response;
	}


	private TokenActivateResponse activateToken(TokenActivateRequest request) {
		logger.debug("Inside activateToken");

		TokenActivateResponse response = null;
		RequestMap requestMap = null;
		Date requestTime = new Date();
		String sysRefNo = null;
		TokenError tokenStatusObj = null;
		
		try {
			requestMap = TokenHelper.prepareRequest(request);
			if(null != requestMap){
				sysRefNo = TokenUtils.getSysRefNo(request.getTokenCommonRequest());
				response = TokenHelper.prepareResponse(tokenService.activateToken(requestMap));	
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.SUCCESS);	
			}
			else {
				logger.error("Request Map for activate request is null");
				response = new TokenActivateResponse();
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
				
			}
		}
		catch(ApiException apiException) {
			logger.error("Api Exception while token activate",apiException);
			response = new TokenActivateResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.API_ERROR, apiException.toString());
			
		}
		catch(Exception exception) {
			logger.error("Generic Exception while token activate",exception);
			response = new TokenActivateResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.GENERIC_ERROR);
			
		}

		response.setTokenError(tokenStatusObj);
		
		try {
			logger.debug("DB logging for token activate");
			tokenLogRepository.save(TokenHelper.prepareTokenLog(requestMap, 
					TokenUtils.xmlMapper.writeValueAsString(request), 
					requestTime, 
					TokenRequestTypeEnum.ACTIVATE_REQUEST, 
					TokenUtils.objectMapper.writeValueAsString(response), 
					new Date(),
					sysRefNo));
		}

		catch(Exception exception) {
			logger.error("Error while logging DB info for token activate",exception);
		}
		return response;
	}

	private TokenUpdateResponse updateToken(TokenUpdateRequest request) {
		logger.debug("Inside updateToken");

		TokenUpdateResponse response = null;
		RequestMap requestMap = null;
		Date requestTime = new Date();
		String sysRefNo = null;
		TokenError tokenStatusObj = null;
		
		try {
			requestMap = TokenHelper.prepareRequest(request);
			if(null != requestMap){
				sysRefNo = TokenUtils.getSysRefNo(request.getTokenCommonRequest());
				response = TokenHelper.prepareResponse(tokenService.updateToken(requestMap));	
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.SUCCESS);	

			}
			else {
				logger.error("Request Map for update request is null");
				response = new TokenUpdateResponse();
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
				
			}
		}
		catch(ApiException apiException) {
			logger.error("Api Exception while token update",apiException);
			response = new TokenUpdateResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.API_ERROR, apiException.toString());
			
		}
		catch(Exception exception) {
			logger.error("Generic Exception while token update",exception);
			response = new TokenUpdateResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.GENERIC_ERROR);
			
		}

		response.setTokenError(tokenStatusObj);
		
		try {
			logger.debug("DB logging for token update");
			tokenLogRepository.save(TokenHelper.prepareTokenLog(requestMap, 
					TokenUtils.xmlMapper.writeValueAsString(request), 
					requestTime, 
					TokenRequestTypeEnum.UPDATE_REQUEST, 
					TokenUtils.objectMapper.writeValueAsString(response), 
					new Date(),
					sysRefNo));
		}

		catch(Exception exception) {
			logger.error("Error while logging DB info for token update",exception);
		}

		return response;
	}

	private TokenSuspendResponse suspendToken(TokenSuspendRequest request) {
		logger.debug("Inside suspendToken");

		TokenSuspendResponse response = null;
		RequestMap requestMap = null;
		Date requestTime = new Date();
		String sysRefNo = null;
		TokenError tokenStatusObj = null;
		
		try {
			requestMap = TokenHelper.prepareRequest(request);
			if(null != requestMap){
				sysRefNo = TokenUtils.getSysRefNo(request.getTokenCommonRequest());
				response = TokenHelper.prepareResponse(tokenService.suspendToken(requestMap));	
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.SUCCESS);	
			}
			else {
				logger.error("Request Map for suspend request is null");
				response = new TokenSuspendResponse();
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
				
			}
		}
		catch(ApiException apiException) {
			logger.error("Api Exception while token suspend",apiException);
			response = new TokenSuspendResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.API_ERROR, apiException.toString());
			
		}
		catch(Exception exception) {
			logger.error("Generic Exception while token suspend",exception);
			response = new TokenSuspendResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.GENERIC_ERROR);
			
		}

		response.setTokenError(tokenStatusObj);
		
		try {
			logger.debug("DB logging for token suspend");
			tokenLogRepository.save(TokenHelper.prepareTokenLog(requestMap, 
					TokenUtils.xmlMapper.writeValueAsString(request), 
					requestTime, 
					TokenRequestTypeEnum.SUSPEND_REQUEST, 
					TokenUtils.objectMapper.writeValueAsString(response), 
					new Date(),
					sysRefNo));
		}

		catch(Exception exception) {
			logger.error("Error while logging DB info for token suspend",exception);
		}

		return response;
	}

	private TokenUnsuspendResponse unsuspendToken(TokenUnsuspendRequest request) {
		logger.debug("Inside unsuspendToken");

		TokenUnsuspendResponse response = null;
		RequestMap requestMap = null;
		Date requestTime = new Date();
		String sysRefNo = null;
		TokenError tokenStatusObj = null;
		
		try {
			requestMap = TokenHelper.prepareRequest(request);
			if(null != requestMap){
				sysRefNo = TokenUtils.getSysRefNo(request.getTokenCommonRequest());
				response = TokenHelper.prepareResponse(tokenService.unsuspendToken(requestMap));	
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.SUCCESS);	
			}
			else {
				logger.error("Request Map for unsuspend request is null");
				response = new TokenUnsuspendResponse();
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
				
			}
		}
		catch(ApiException apiException) {
			logger.error("Api Exception while token unsuspend",apiException);
			response = new TokenUnsuspendResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.API_ERROR, apiException.toString());
			
		}
		catch(Exception exception) {
			logger.error("Generic Exception while token unsuspend",exception);
			response = new TokenUnsuspendResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.GENERIC_ERROR);
			
		}

		response.setTokenError(tokenStatusObj);
		
		try {
			logger.debug("DB logging for token unsuspend");
			tokenLogRepository.save(TokenHelper.prepareTokenLog(requestMap, 
					TokenUtils.xmlMapper.writeValueAsString(request), 
					requestTime, 
					TokenRequestTypeEnum.UNSUSPEND_REQUEST, 
					TokenUtils.objectMapper.writeValueAsString(response), 
					new Date(),
					sysRefNo));
		}

		catch(Exception exception) {
			logger.error("Error while logging DB info for token unsuspend",exception);
		}

		return response;
	}

	private TokenDeleteResponse deleteToken(TokenDeleteRequest request) {
		logger.debug("Inside deleteToken");

		TokenDeleteResponse response = null;
		RequestMap requestMap = null;
		Date requestTime = new Date();
		String sysRefNo = null;
		TokenError tokenStatusObj = null;
		
		try {
			requestMap = TokenHelper.prepareRequest(request);
			if(null != requestMap){
				sysRefNo = TokenUtils.getSysRefNo(request.getTokenCommonRequest());
				response = TokenHelper.prepareResponse(tokenService.deleteToken(requestMap));	
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.SUCCESS);
			}
			else {
				logger.error("Request Map for delete request is null");
				response = new TokenDeleteResponse();
				tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.VALIDATION_ERROR);
				
			}
		}
		catch(ApiException apiException) {
			logger.error("Api Exception while token delete",apiException);
			response = new TokenDeleteResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.API_ERROR, apiException.toString());
			
		}
		catch(Exception exception) {
			logger.error("Generic Exception while token delete",exception);
			response = new TokenDeleteResponse();
			tokenStatusObj = TokenHelper.createTokenError(TokenErrorEnum.GENERIC_ERROR);
			
		}

		response.setTokenError(tokenStatusObj);
		
		try {
			logger.debug("DB logging for token delete");
			tokenLogRepository.save(TokenHelper.prepareTokenLog(requestMap, 
					TokenUtils.xmlMapper.writeValueAsString(request), 
					requestTime, 
					TokenRequestTypeEnum.DELETE_REQUEST, 
					TokenUtils.objectMapper.writeValueAsString(response), 
					new Date(),
					sysRefNo));
		}

		catch(Exception exception) {
			logger.error("Error while logging DB info for token delete",exception);
		}

		return response;
	}


}