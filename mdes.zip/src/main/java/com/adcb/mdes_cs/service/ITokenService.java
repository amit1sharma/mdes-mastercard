package com.adcb.mdes_cs.service;

import com.mastercard.api.core.exception.ApiException;
import com.mastercard.api.core.model.RequestMap;
import com.mastercard.api.mdescustomerservice.Search;
import com.mastercard.api.mdescustomerservice.TokenActivate;
import com.mastercard.api.mdescustomerservice.TokenDelete;
import com.mastercard.api.mdescustomerservice.TokenSuspend;
import com.mastercard.api.mdescustomerservice.TokenUnsuspend;
import com.mastercard.api.mdescustomerservice.TokenUpdate;

public interface ITokenService {

	public Search searchToken(RequestMap requestMap) throws ApiException; 
	
	public TokenActivate activateToken(RequestMap requestMap) throws ApiException;
	
	public TokenSuspend suspendToken(RequestMap requestMap) throws ApiException;
	
	public TokenUnsuspend unsuspendToken(RequestMap requestMap) throws ApiException;
	
	public TokenDelete deleteToken(RequestMap requestMap) throws ApiException;
	
	public TokenUpdate updateToken(RequestMap requestMap) throws ApiException;
	 
}
