package com.adcb.mdes_cs.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.mastercard.api.core.exception.ApiException;
import com.mastercard.api.core.model.RequestMap;
import com.mastercard.api.mdescustomerservice.Search;
import com.mastercard.api.mdescustomerservice.TokenActivate;
import com.mastercard.api.mdescustomerservice.TokenDelete;
import com.mastercard.api.mdescustomerservice.TokenSuspend;
import com.mastercard.api.mdescustomerservice.TokenUnsuspend;
import com.mastercard.api.mdescustomerservice.TokenUpdate;

@Service
public class TokenService implements ITokenService{
	
	private static final Logger logger = LogManager.getLogger(TokenService.class);
	
	@Override
	public Search searchToken(RequestMap requestMap) throws ApiException {
		logger.debug("Calling final search token service");
		return Search.create(requestMap);
	}

	@Override
	public TokenActivate activateToken(RequestMap requestMap) throws ApiException {
		logger.debug("Calling final activate token service");
		return TokenActivate.create(requestMap);
	}

	@Override
	public TokenSuspend suspendToken(RequestMap requestMap) throws ApiException {
		logger.debug("Calling final suspend token service");
		return TokenSuspend.create(requestMap);
	}

	@Override
	public TokenUnsuspend unsuspendToken(RequestMap requestMap) throws ApiException {
		logger.debug("Calling final unsuspend token service");
		return TokenUnsuspend.create(requestMap);
	}

	@Override
	public TokenDelete deleteToken(RequestMap requestMap) throws ApiException {
		logger.debug("Calling final delete token service");
		return TokenDelete.create(requestMap);
	}

	@Override
	public TokenUpdate updateToken(RequestMap requestMap) throws ApiException {
		logger.debug("Calling final update token service");
		return TokenUpdate.create(requestMap);
	}

}
